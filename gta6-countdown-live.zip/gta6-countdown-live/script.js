// Target is interpreted in India Standard Time (UTC+05:30).
// Change the date below only if the official launch date changes.
const launchAt = new Date("2026-11-19T00:00:00+05:30").getTime();

const el = id => document.getElementById(id);
const pad = value => String(value).padStart(2, "0");

function updateCountdown() {
  const remaining = launchAt - Date.now();

  if (remaining <= 0) {
    ["days", "hours", "minutes", "seconds"].forEach(id => el(id).textContent = "00");
    el("status").textContent = "LAUNCH DAY IS HERE";
    return;
  }

  const totalSeconds = Math.floor(remaining / 1000);
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;

  el("days").textContent = String(days).padStart(3, "0");
  el("hours").textContent = pad(hours);
  el("minutes").textContent = pad(minutes);
  el("seconds").textContent = pad(seconds);
}
updateCountdown();
setInterval(updateCountdown, 1000);
