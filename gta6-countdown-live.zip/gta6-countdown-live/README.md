# GTA VI Countdown Live — Vice City Neon

A lightweight, browser-based 16:9 countdown overlay. It is designed as a visual source for a livestream encoder; **it does not broadcast to YouTube by itself**.

## Files
- `index.html` — layout
- `style.css` — neon Vice City-inspired styling
- `script.js` — live countdown timer

## Preview
Open `index.html` in a browser. The countdown target is set to **19 November 2026, 00:00 India Standard Time**.

## Stream use
A livestream encoder/host must load this page as a browser source and send the resulting video to YouTube using YouTube's authorized live-streaming workflow. Typical browser-source canvas size: **1920 × 1080**.

This repository alone is not an always-on streaming server. GitHub Pages can host the page, but it cannot continuously encode and broadcast a live video. An always-on streaming host/encoder is needed for 24/7 streaming without keeping a phone running.

## Important
- This is an unofficial fan-made countdown visual and is not affiliated with Rockstar Games.
- No GTA VI logos, screenshots, music, or game footage are included.
- Check the official release date before streaming; edit `launchAt` in `script.js` if it changes.
- Follow YouTube's current livestreaming eligibility and age/supervision requirements.
